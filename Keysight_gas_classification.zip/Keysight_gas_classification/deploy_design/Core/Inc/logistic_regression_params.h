
/*
//Program Size: Code=18124 RO-data=668 RW-data=48 ZI-data=9280  
// latency : 0.54
float lr_coeff [] = { -0.32658392814492504, 0.04839734312015034, 0.022258396775121203, -0.18681602288256435};
float lr_intercept  = 17.826229586309143; 
int sample_size = 1;
float sigma = 1.8;
int window = 38;
*/

/*
//Program Size: Code=18124 RO-data=668 RW-data=48 ZI-data=9280
// latency : 0.32
// --sample_size 2 --window 22 --sigma 1.7
float lr_coeff [] = { -0.24217008764008952, 0.04197839817336907, 0.020863173891057733, -0.16907936982090158};
float lr_intercept  = 15.652010885588387; 
int sample_size = 2;
float sigma = 1.7;
int window = 22;
*/


//Program Size: Code=18124 RO-data=668 RW-data=48 ZI-data=9280 
// latency : 0.252
float lr_coeff [] = { -0.38735771532034824, 0.047507908110267165, 0.029339947727241543, -0.19527614084247039};
float lr_intercept  = 18.648928456058076; 
int sample_size = 3;
float sigma = 1.8000000000000003;
int window = 36;

